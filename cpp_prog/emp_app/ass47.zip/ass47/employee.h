class employee{

int emp_id;
char name[20];
int dob;

public:  
        employee();
        employee(int , char* , dob);
        void show();

};
