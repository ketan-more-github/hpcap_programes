#include<iostream>
using namespace std;





int main()  {

try{
int a =10;
int b = 0;
int ans ;
ans= a/b;
cout<<ans<<endl;
cout<<"in try block"<<endl;

}catch(){
cout<<"in cath block"<<endl;
}


return 0;
}

