
class date{

int dd,mm,yy;

public : 
        date();
        date(int,int,int);
         void display();

};
