#include<stdio.h>

int main()
{
char ch;
char asc;
printf("Enter a character t get its ascci value\n");
scanf("%c" , &ch);


printf("its ascci value = %d \n" , ch);

return 0; 
}
