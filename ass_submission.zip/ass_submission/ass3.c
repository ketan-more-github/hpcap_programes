#include<stdio.h>

int main()
{
int a ,b ,c;
 a = 100;
 b = 200;
 c = a+b;
printf("addition is = %d\n" ,c
);

return 0; 
}
