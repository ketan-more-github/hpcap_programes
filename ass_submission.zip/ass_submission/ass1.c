#include<stdio.h>

int main()
{
// back slash r give the cursor to the start of a same line

printf("hello \rjay\n");
printf("hello\\jay\n");
printf("hello\t\t jay\n");
printf("50%%\n");
printf("hello \"jay\" \n");
return 0;
}
